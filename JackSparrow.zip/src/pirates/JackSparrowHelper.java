package pirates;

public interface JackSparrowHelper {
    /**
     * @param path
     * @param numberOfGallons
     * @return <tt>Purchases</tt>
     */
    Purchases helpJackSparrow(String path, int numberOfGallons);
}
